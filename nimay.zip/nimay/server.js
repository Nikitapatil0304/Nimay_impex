const express = require("express");
const db = require("./db");

const app = express();
const PORT = 5000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Test route
app.get("/", (req, res) => {
    res.send("NIMAY IMPEX Backend is Running!");
});

// Buyer Enquiry API
app.post("/api/enquiries", (req, res) => {
    const {
        name,
        company,
        email,
        phone,
        country,
        product,
        quantity,
        message
    } = req.body;

    // Required fields check
    if (!name || !email || !country || !message) {
        return res.status(400).json({
            success: false,
            message: "Please fill all required fields."
        });
    }

    const sql = `
        INSERT INTO buyer_inquiries
        (name, company, email, phone, country, product, quantity, message)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [
        name,
        company || null,
        email,
        phone || null,
        country,
        product || null,
        quantity || null,
        message
    ];

    db.query(sql, values, (err, result) => {
        if (err) {
            console.error("Database error:", err.message);

            return res.status(500).json({
                success: false,
                message: "Failed to save enquiry."
            });
        }

        console.log("New enquiry saved. ID:", result.insertId);

        res.status(201).json({
            success: true,
            message: "Your enquiry has been submitted successfully!",
            enquiryId: result.insertId
        });
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});