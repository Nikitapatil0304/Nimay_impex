/* ==========================================================================
   NIMAY IMPEX — script.js
   ========================================================================== */

/* ---------------------------------------------------------------------
   PRODUCT DATA
   Each product carries a "swatch" colour pair that accurately represents
   the real colour of that ingredient. This is used to render the visual
   until a real photo is added (see attachImageFallback below).
   --------------------------------------------------------------------- */
const PRODUCTS = [
  // DEHYDRATED PRODUCTS
  { id:"onion-powder", name:"Dehydrated Onion Powder", category:"dehydrated", categoryLabel:"Dehydrated Products",
    swatch:["#F1E6C8","#D9C08C"], desc:"Finely milled dehydrated onion, processed for consistent aroma, colour and particle size.",
    applications:["Snack Seasoning","Soups & Sauces","Ready-to-Cook Mixes","Spice Blends"],
    benefits:["Long shelf life","Consistent particle size","Retains natural aroma","Easy to dose & blend"],
    packaging:"25kg multi-layer craft bags with inner poly liner (custom packaging available)",
    storage:"Store in a cool, dry place away from direct sunlight and moisture",
    shelfLife:"12–18 months from date of packing, unopened" },
  { id:"garlic-powder", name:"Dehydrated Garlic Powder", category:"dehydrated", categoryLabel:"Dehydrated Products",
    swatch:["#F5EFDD","#E3D6B0"], desc:"Pure dehydrated garlic ground to a fine, free-flowing powder with strong natural pungency.",
    applications:["Seasoning Blends","Sauces & Pickles","Snacks","Ready-to-Cook Foods"],
    benefits:["Strong natural flavour","Free-flowing texture","No added fillers","Bulk & retail packing available"],
    packaging:"25kg craft bags with inner liner; smaller export cartons on request",
    storage:"Keep sealed in a cool, dry, odour-free storage area",
    shelfLife:"12–18 months from date of packing, unopened" },
  { id:"onion-flakes", name:"Onion Flakes", category:"dehydrated", categoryLabel:"Dehydrated Products",
    swatch:["#E9DCB8","#C9AD72"], desc:"Sun-dried and dehydrated onion pieces, cut and graded for uniform size.",
    applications:["Instant Noodles & Soups","Snack Toppings","Namkeen & Savouries","Sauces"],
    benefits:["Rehydrates quickly","Uniform flake size","Natural colour retention","Bulk export packing"],
    packaging:"20–25kg export cartons or craft bags with liner",
    storage:"Store away from humidity in a ventilated, dry warehouse",
    shelfLife:"12 months from date of packing, unopened" },
  { id:"garlic-flakes", name:"Garlic Flakes", category:"dehydrated", categoryLabel:"Dehydrated Products",
    swatch:["#F2ECDA","#DBCB9C"], desc:"Dehydrated garlic flakes graded for size, ideal for snack and seasoning applications.",
    applications:["Snack Seasoning","Instant Foods","Sauces & Dips","Spice Blends"],
    benefits:["Sharp natural aroma","Consistent grading","Good rehydration","Custom mesh sizes on request"],
    packaging:"20–25kg export cartons or craft bags with liner",
    storage:"Store in a cool, dry place, protected from moisture",
    shelfLife:"12 months from date of packing, unopened" },
  { id:"vegetable-powder", name:"Vegetable Powder", category:"dehydrated", categoryLabel:"Dehydrated Products",
    swatch:["#B9C384","#7E9450"], desc:"Blended dehydrated vegetable powder for use as a natural base in food formulations.",
    applications:["Soups & Broths","Baby & Health Foods (as an ingredient)","Snack Seasoning","Sauces"],
    benefits:["Natural vegetable base","Custom blends available","Consistent quality","Bulk supply capability"],
    packaging:"25kg multi-layer bags with inner liner",
    storage:"Keep in a cool, dry, pest-free storage environment",
    shelfLife:"12 months from date of packing, unopened" },

  // SPICES & SPICE POWDERS
  { id:"chilli-powder", name:"Red Chilli Powder", category:"spices", categoryLabel:"Spices & Spice Powders",
    swatch:["#C34A2C","#7E2213"], desc:"Vibrant red chilli powder milled from quality-graded dried red chillies.",
    applications:["Curries & Gravies","Snacks & Namkeen","Sauces & Marinades","Spice Blends"],
    benefits:["Rich natural colour","Consistent heat level","Fine, uniform grinding","Custom heat grades available"],
    packaging:"25kg bags or export cartons; smaller lots on request",
    storage:"Store in airtight conditions away from light and moisture",
    shelfLife:"12 months from date of packing, unopened" },
  { id:"turmeric-powder", name:"Turmeric Powder", category:"spices", categoryLabel:"Spices & Spice Powders",
    swatch:["#E3A82A","#A9750F"], desc:"Golden turmeric powder ground from selected turmeric roots for colour and flavour.",
    applications:["Curries","Spice Blends","Sauces & Pickles","Food Colouring Base"],
    benefits:["High natural colour value","Fine consistent texture","Hygienically processed","Bulk export packing"],
    packaging:"25kg bags or export cartons",
    storage:"Store in a cool, dry, dark place",
    shelfLife:"18 months from date of packing, unopened" },
  { id:"coriander-powder", name:"Coriander Powder", category:"spices", categoryLabel:"Spices & Spice Powders",
    swatch:["#9A8552","#6C5A32"], desc:"Aromatic coriander powder milled from cleaned, graded coriander seed.",
    applications:["Curries & Gravies","Spice Blends","Snack Seasoning","Marinades"],
    benefits:["Fresh aromatic profile","Fine milling","Consistent quality lots","Custom packing available"],
    packaging:"25kg bags or export cartons",
    storage:"Store away from moisture and strong odours",
    shelfLife:"12 months from date of packing, unopened" },
  { id:"cumin-powder", name:"Cumin Powder", category:"spices", categoryLabel:"Spices & Spice Powders",
    swatch:["#8A6534","#5B421F"], desc:"Freshly milled cumin powder with a strong, warm aroma for everyday and industrial use.",
    applications:["Curries","Spice Blends","Snack Seasoning","Sauces"],
    benefits:["Strong natural aroma","Fine texture","Hygienic processing","Bulk supply available"],
    packaging:"25kg bags or export cartons",
    storage:"Store in a cool, dry, airtight environment",
    shelfLife:"12 months from date of packing, unopened" },
  { id:"pepper-powder", name:"Black Pepper Powder", category:"spices", categoryLabel:"Spices & Spice Powders",
    swatch:["#4A3B2E","#241A13"], desc:"Pungent black pepper powder ground from quality peppercorns.",
    applications:["Seasoning","Sauces & Marinades","Spice Blends","Ready-to-Cook Foods"],
    benefits:["Strong natural pungency","Fine consistent grind","Custom mesh sizes","Export-grade quality"],
    packaging:"25kg bags or export cartons",
    storage:"Store sealed, away from moisture and light",
    shelfLife:"12 months from date of packing, unopened" },
  { id:"garam-masala", name:"Garam Masala", category:"spices", categoryLabel:"Spices & Spice Powders",
    swatch:["#7A4423","#4A2712"], desc:"A balanced blend of traditional whole spices, ground for a warm, layered flavour.",
    applications:["Curries & Gravies","Snack Seasoning","Marinades","Ready-to-Cook Foods"],
    benefits:["Balanced traditional recipe","Custom blend formulation available","Consistent batch quality","Bulk & retail packing"],
    packaging:"25kg bags or export cartons; custom retail pouches on request",
    storage:"Store in a cool, dry, airtight environment",
    shelfLife:"9–12 months from date of packing, unopened" },
  { id:"spice-blends", name:"Spice Blends & Mixes", category:"spices", categoryLabel:"Spices & Spice Powders",
    swatch:["#A85A22","#6E3712"], desc:"Custom-formulated spice blends developed to buyer specification for regional cuisines.",
    applications:["Snack Manufacturing","Sauces & Marinades","Ready-to-Cook Foods","Food Service"],
    benefits:["Custom formulation to spec","Batch-consistent flavour","Private labelling available","Bulk industrial supply"],
    packaging:"25kg bags or export cartons; formulation-specific packing available",
    storage:"Store in a cool, dry, airtight environment",
    shelfLife:"9–12 months from date of packing, unopened" },

  // SEEDS
  { id:"sesame-seeds", name:"Sesame Seeds", category:"seeds", categoryLabel:"Seeds",
    swatch:["#EFE8D2","#D6C79A"], desc:"Clean, machine-graded sesame seeds with high purity and uniform size.",
    applications:["Bakery & Confectionery","Snacks","Oil Extraction","Seasoning Toppings"],
    benefits:["High purity grading","Uniform seed size","Natural oil content","Export-grade cleaning"],
    packaging:"25–50kg export bags; jute or PP bags on request",
    storage:"Store in a cool, dry, pest-controlled warehouse",
    shelfLife:"12 months from date of packing, unopened" },
  { id:"cumin-seeds", name:"Cumin Seeds", category:"seeds", categoryLabel:"Seeds",
    swatch:["#8F6E3D","#5F4726"], desc:"Whole cumin seeds, machine-cleaned and graded for aroma and size consistency.",
    applications:["Whole-Spice Seasoning","Tempering & Cooking","Spice Blends","Beverages"],
    benefits:["Strong natural aroma","Machine-cleaned & graded","Low foreign matter","Bulk export supply"],
    packaging:"25–50kg export bags",
    storage:"Store in a cool, dry, airtight environment",
    shelfLife:"12 months from date of packing, unopened" },
  { id:"coriander-seeds", name:"Coriander Seeds", category:"seeds", categoryLabel:"Seeds",
    swatch:["#B9A15C","#8A7639"], desc:"Whole coriander seeds cleaned and graded for size, colour and aroma.",
    applications:["Whole-Spice Cooking","Spice Powder Milling","Pickling","Spice Blends"],
    benefits:["Consistent grading","Fresh aromatic profile","Low moisture content","Export-grade cleaning"],
    packaging:"25–50kg export bags",
    storage:"Store in a cool, dry, ventilated space",
    shelfLife:"12 months from date of packing, unopened" },
  { id:"fennel-seeds", name:"Fennel Seeds", category:"seeds", categoryLabel:"Seeds",
    swatch:["#9FB06C","#6D7F44"], desc:"Aromatic fennel seeds, machine-graded for uniform size and colour.",
    applications:["Whole-Spice Cooking","Mouth Fresheners","Beverages","Spice Blends"],
    benefits:["Sweet aromatic profile","Uniform grading","Low foreign matter","Bulk export supply"],
    packaging:"25–50kg export bags",
    storage:"Store in a cool, dry, airtight environment",
    shelfLife:"12 months from date of packing, unopened" },
  { id:"fenugreek-seeds", name:"Fenugreek Seeds", category:"seeds", categoryLabel:"Seeds",
    swatch:["#C7A961","#95793A"], desc:"Whole fenugreek seeds cleaned and graded for consistent size and colour.",
    applications:["Whole-Spice Cooking","Spice Blends","Pickling","Sprouting"],
    benefits:["Consistent grading","Low moisture content","Export-grade cleaning","Bulk supply available"],
    packaging:"25–50kg export bags",
    storage:"Store in a cool, dry, ventilated space",
    shelfLife:"12 months from date of packing, unopened" },
  { id:"mustard-seeds", name:"Mustard Seeds", category:"seeds", categoryLabel:"Seeds",
    swatch:["#8A6A28","#5C4718"], desc:"Machine-cleaned mustard seeds graded for size and oil content.",
    applications:["Whole-Spice Tempering","Oil Extraction","Pickling","Spice Blends"],
    benefits:["High purity grading","Consistent oil content","Low foreign matter","Bulk export supply"],
    packaging:"25–50kg export bags",
    storage:"Store in a cool, dry, airtight environment",
    shelfLife:"12 months from date of packing, unopened" },
  { id:"chia-seeds", name:"Chia Seeds", category:"seeds", categoryLabel:"Seeds",
    swatch:["#2E2A24","#151310"], desc:"Clean, graded chia seeds with consistent size and high purity.",
    applications:["Health & Snack Foods","Bakery","Beverages","Food Formulation"],
    benefits:["High purity grading","Uniform seed size","Natural product","Export-grade cleaning"],
    packaging:"25kg export bags; smaller export cartons on request",
    storage:"Store in a cool, dry, pest-controlled warehouse",
    shelfLife:"18 months from date of packing, unopened" },
  { id:"flax-seeds", name:"Flax Seeds", category:"seeds", categoryLabel:"Seeds",
    swatch:["#7A5430","#4E3419"], desc:"Machine-cleaned flax seeds (linseed) graded for size and purity.",
    applications:["Bakery","Health Foods","Oil Extraction","Food Formulation"],
    benefits:["High purity grading","Consistent seed size","Natural oil content","Bulk export supply"],
    packaging:"25kg export bags",
    storage:"Store in a cool, dry, airtight environment",
    shelfLife:"12 months from date of packing, unopened" },
  { id:"pumpkin-seeds", name:"Pumpkin Seeds", category:"seeds", categoryLabel:"Seeds",
    swatch:["#D2CD97","#A6A162"], desc:"Hulled pumpkin seeds, machine-graded for size and colour consistency.",
    applications:["Snacks","Bakery","Health Foods","Food Formulation"],
    benefits:["Clean hulled kernels","Uniform grading","Natural product","Export-grade cleaning"],
    packaging:"25kg export bags; vacuum packing on request",
    storage:"Store in a cool, dry, pest-controlled warehouse",
    shelfLife:"9–12 months from date of packing, unopened" },
  { id:"sunflower-seeds", name:"Sunflower Seeds", category:"seeds", categoryLabel:"Seeds",
    swatch:["#585047","#332D27"], desc:"Machine-cleaned sunflower seeds graded for size and kernel quality.",
    applications:["Snacks","Bakery","Oil Extraction","Food Formulation"],
    benefits:["High purity grading","Consistent kernel size","Natural oil content","Bulk export supply"],
    packaging:"25–50kg export bags",
    storage:"Store in a cool, dry, ventilated space",
    shelfLife:"12 months from date of packing, unopened" },
];

const WHATSAPP_NUMBER = "919316623744";
const CONTACT_EMAIL = "nimayimpex@gmail.com";

/* ---------------------------------------------------------------------
   IMAGE FALLBACK HELPER
   Call this on any <img class="swatch-photo"> pointing at /images/...
   If the file is missing, the image hides and the colour swatch below
   it shows through automatically — so a broken-image icon can never
   appear, whether or not real photos have been added yet.
   --------------------------------------------------------------------- */
function attachImageFallback(img){
  img.addEventListener("error", () => { img.style.display = "none"; }, { once:true });
}

function swatchFillHTML(swatch, label, imgSrc){
  const grad = `linear-gradient(155deg, ${swatch[0]}, ${swatch[1]})`;
  const photo = imgSrc ? `<img class="swatch-photo" src="${imgSrc}" alt="${label}">` : "";
  return `<div class="swatch-fill" style="background:${grad}">${photo}<div class="swatch-glyph">${label}</div></div>`;
}

/* ---------------------------------------------------------------------
   NAVBAR
   --------------------------------------------------------------------- */
function initNavbar(){
  const navbar = document.querySelector(".navbar");
  const hamburger = document.querySelector(".hamburger");
  const mobileMenu = document.querySelector(".mobile-menu");
  if (navbar){
    window.addEventListener("scroll", () => {
      navbar.classList.toggle("scrolled", window.scrollY > 30);
    });
  }
  if (hamburger && mobileMenu){
    hamburger.addEventListener("click", () => {
      hamburger.classList.toggle("open");
      mobileMenu.classList.toggle("open");
      document.body.style.overflow = mobileMenu.classList.contains("open") ? "hidden" : "";
    });
    mobileMenu.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
      hamburger.classList.remove("open");
      mobileMenu.classList.remove("open");
      document.body.style.overflow = "";
    }));
  }
}

/* ---------------------------------------------------------------------
   SCROLL REVEAL
   --------------------------------------------------------------------- */
function initReveal(){
  const items = document.querySelectorAll(".reveal, .reveal-stagger");
  if (!("IntersectionObserver" in window)){
    items.forEach(el => el.classList.add("in"));
    return;
  }
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting){
        entry.target.classList.add("in");
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  items.forEach(el => io.observe(el));
}

/* ---------------------------------------------------------------------
   BACK TO TOP
   --------------------------------------------------------------------- */
function initBackToTop(){
  const btn = document.querySelector(".back-to-top");
  if (!btn) return;
  window.addEventListener("scroll", () => {
    btn.classList.toggle("show", window.scrollY > 500);
  });
  btn.addEventListener("click", () => window.scrollTo({ top:0, behavior:"smooth" }));
}

/* ---------------------------------------------------------------------
   HOME PAGE: category preview + gallery
   --------------------------------------------------------------------- */
function buildCategoryPreview(){
  const grid = document.querySelector("[data-category-grid]");
  if (!grid) return;
  const cats = [
    { key:"dehydrated", title:"Dehydrated Products", desc:"Onion, garlic and vegetable powders & flakes processed for consistent quality and long shelf life.", swatch:["#E9DCB8","#B79A5C"], img:"images/category-dehydrated.jpg" },
    { key:"spices", title:"Spices & Spice Powders", desc:"Chilli, turmeric, coriander, cumin, pepper and custom-formulated spice blends.", swatch:["#C34A2C","#7E2213"], img:"images/category-spices.jpg" },
    { key:"seeds", title:"Seeds", desc:"Sesame, cumin, coriander, fennel, chia, flax and other export-grade seeds.", swatch:["#8F6E3D","#5F4726"], img:"images/category-seeds.jpg" },
  ];
  grid.innerHTML = cats.map(c => `
    <div class="cat-card">
      <div class="cat-visual">
        <span class="cat-tag">${PRODUCTS.filter(p=>p.category===c.key).length} Products</span>
        ${swatchFillHTML(c.swatch, c.title, c.img)}
      </div>
      <div class="cat-body">
        <h3>${c.title}</h3>
        <p>${c.desc}</p>
        <a class="btn btn-ghost" href="products.html#${c.key}" data-cat-link="${c.key}">Explore ${c.title}</a>
      </div>
    </div>`).join("");
  grid.querySelectorAll("img.swatch-photo").forEach(attachImageFallback);
}

function buildGallery(){
  const grid = document.querySelector("[data-gallery-grid]");
  if (!grid) return;
  const items = [
    { cat:"Products", label:"Export-Ready Product Range", swatch:["#E08829","#B9631A"] },
    { cat:"Spices", label:"Ground Spice Powders", swatch:["#C34A2C","#7E2213"] },
    { cat:"Spices", label:"Whole Spice Selection", swatch:["#D9A441","#A9750F"] },
    { cat:"Seeds", label:"Graded Seed Lots", swatch:["#8F6E3D","#5F4726"] },
    { cat:"Seeds", label:"Cleaned & Sorted Seeds", swatch:["#B9A15C","#8A7639"] },
    { cat:"Dehydrated Products", label:"Onion & Garlic Powders", swatch:["#F1E6C8","#D9C08C"] },
    { cat:"Dehydrated Products", label:"Vegetable Flakes", swatch:["#E9DCB8","#C9AD72"] },
    { cat:"Packaging", label:"Export Bag & Carton Packing", swatch:["#7A5430","#4E3419"] },
    { cat:"Export / Shipping", label:"Container Loading & Dispatch", swatch:["#1E4430","#0F2418"] },
    { cat:"Packaging", label:"Bulk & Retail Packing Options", swatch:["#9FB06C","#6D7F44"] },
    { cat:"Export / Shipping", label:"Documentation & Quality Checks", swatch:["#2C5A40","#153421"] },
    { cat:"Products", label:"Sample Index Across Categories", swatch:["#A85A22","#6E3712"] },
  ];
  window.__GALLERY_ITEMS = items;
  grid.innerHTML = items.map((it,i) => `
    <div class="gitem reveal" data-gcat="${it.cat}" data-index="${i}">
      ${swatchFillHTML(it.swatch,"")}
      <div class="gitem-label"><span>${it.cat}</span>${it.label}</div>
    </div>`).join("");

  document.querySelectorAll(".gfilter").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".gfilter").forEach(b=>b.classList.remove("active"));
      btn.classList.add("active");
      const f = btn.dataset.filter;
      document.querySelectorAll(".gitem").forEach(g => {
        g.style.display = (f === "All" || g.dataset.gcat === f) ? "" : "none";
      });
    });
  });

  document.querySelectorAll(".gitem").forEach(g => g.addEventListener("click", () => openLightbox(parseInt(g.dataset.index,10))));
  initReveal();
}

/* ---------------------------------------------------------------------
   LIGHTBOX
   --------------------------------------------------------------------- */
let lightboxIndex = 0;
function openLightbox(index){
  const items = window.__GALLERY_ITEMS;
  if (!items) return;
  lightboxIndex = index;
  renderLightbox();
  document.querySelector(".lightbox").classList.add("open");
  document.body.style.overflow = "hidden";
}
function renderLightbox(){
  const items = window.__GALLERY_ITEMS;
  const it = items[lightboxIndex];
  const visual = document.querySelector(".lightbox-visual");
  visual.innerHTML = swatchFillHTML(it.swatch,"");
  document.querySelector(".lightbox-inner span").textContent = it.cat;
  document.querySelector(".lightbox-inner h4").textContent = it.label;
}
function initLightbox(){
  const lb = document.querySelector(".lightbox");
  if (!lb) return;
  document.querySelector(".lightbox-close").addEventListener("click", closeLightbox);
  lb.addEventListener("click", (e) => { if (e.target === lb) closeLightbox(); });
  document.querySelector(".lightbox-prev").addEventListener("click", () => {
    lightboxIndex = (lightboxIndex - 1 + window.__GALLERY_ITEMS.length) % window.__GALLERY_ITEMS.length;
    renderLightbox();
  });
  document.querySelector(".lightbox-next").addEventListener("click", () => {
    lightboxIndex = (lightboxIndex + 1) % window.__GALLERY_ITEMS.length;
    renderLightbox();
  });
  document.addEventListener("keydown", (e) => {
    if (!lb.classList.contains("open")) return;
    if (e.key === "Escape") closeLightbox();
  });
}
function closeLightbox(){
  document.querySelector(".lightbox").classList.remove("open");
  document.body.style.overflow = "";
}

/* ---------------------------------------------------------------------
   PRODUCTS PAGE: grid, filters, modal
   --------------------------------------------------------------------- */
function buildProductGrid(filter){
  const grid = document.querySelector("[data-product-grid]");
  if (!grid) return;
  const list = (!filter || filter === "all") ? PRODUCTS : PRODUCTS.filter(p => p.category === filter);
  document.querySelector("[data-count]").textContent = `${list.length} Product${list.length===1?"":"s"}`;
  document.querySelector(".empty-state").classList.toggle("show", list.length === 0);

  grid.innerHTML = list.map(p => `
    <div class="pcard reveal">
      <div class="pcard-visual">
        <span class="pcard-cat">${p.categoryLabel}</span>
        ${swatchFillHTML(p.swatch, p.name, `images/${p.id}.jpg`)}
      </div>
      <div class="pcard-body">
        <h4>${p.name}</h4>
        <p>${p.desc}</p>
        <div class="pcard-actions">
          <button class="btn btn-dark btn-sm" data-open-modal="${p.id}">View Details</button>
          <a class="btn btn-ghost btn-sm" href="${waLink('Enquiry about ' + p.name)}" target="_blank" rel="noopener">Get Quote</a>
        </div>
      </div>
    </div>`).join("");

  grid.querySelectorAll("img.swatch-photo").forEach(attachImageFallback);
  grid.querySelectorAll("[data-open-modal]").forEach(btn => {
    btn.addEventListener("click", () => openProductModal(btn.dataset.openModal));
  });
  initReveal();
}

function initProductFilters(){
  const filterBar = document.querySelector("[data-filters]");
  if (!filterBar) return;
  filterBar.querySelectorAll(".cfilter").forEach(btn => {
    btn.addEventListener("click", () => {
      filterBar.querySelectorAll(".cfilter").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      buildProductGrid(btn.dataset.filter);
    });
  });
  // deep-link via hash, e.g. products.html#seeds
  const hash = window.location.hash.replace("#","");
  const match = filterBar.querySelector(`[data-filter="${hash}"]`);
  if (match){
    filterBar.querySelectorAll(".cfilter").forEach(b => b.classList.remove("active"));
    match.classList.add("active");
    buildProductGrid(hash);
  } else {
    buildProductGrid("all");
  }
}

function waLink(message){
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

function openProductModal(id){
  const p = PRODUCTS.find(x => x.id === id);
  if (!p) return;
  const backdrop = document.querySelector(".pmodal-backdrop");
  document.querySelector("[data-modal-visual]").innerHTML = swatchFillHTML(p.swatch, p.name, `images/${p.id}.jpg`);
  document.querySelector("[data-modal-visual] img.swatch-photo") && attachImageFallback(document.querySelector("[data-modal-visual] img.swatch-photo"));
  document.querySelector("[data-modal-cat]").textContent = p.categoryLabel;
  document.querySelector("[data-modal-name]").textContent = p.name;
  document.querySelector("[data-modal-desc]").textContent = p.desc;
  document.querySelector("[data-modal-packaging]").textContent = p.packaging;
  document.querySelector("[data-modal-storage]").textContent = p.storage;
  document.querySelector("[data-modal-shelflife]").textContent = p.shelfLife;
  document.querySelector("[data-modal-applications]").innerHTML = p.applications.map(a=>`<li>${a}</li>`).join("");
  document.querySelector("[data-modal-benefits]").innerHTML = p.benefits.map(a=>`<li>${a}</li>`).join("");
  document.querySelector("[data-modal-whatsapp]").href = waLink(`Hello Nimay Impex, I would like a quote for ${p.name}.`);
  document.querySelector("[data-modal-email]").href = `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent("Enquiry: " + p.name)}&body=${encodeURIComponent("Hello Nimay Impex,\n\nI would like more information / a quote for " + p.name + ".\n\nRegards,")}`;
  backdrop.classList.add("open");
  document.body.style.overflow = "hidden";
}
function closeProductModal(){
  document.querySelector(".pmodal-backdrop").classList.remove("open");
  document.body.style.overflow = "";
}
function initProductModal(){
  const backdrop = document.querySelector(".pmodal-backdrop");
  if (!backdrop) return;
  document.querySelector(".pmodal-close").addEventListener("click", closeProductModal);
  backdrop.addEventListener("click", (e) => { if (e.target === backdrop) closeProductModal(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && backdrop.classList.contains("open")) closeProductModal(); });
}

/* ---------------------------------------------------------------------
   INTERESTED PRODUCT DROPDOWN (contact form)
   --------------------------------------------------------------------- */
function fillProductSelect(){
  const sel = document.querySelector("[data-product-select]");
  if (!sel) return;
  PRODUCTS.forEach(p => {
    const opt = document.createElement("option");
    opt.value = p.name;
    opt.textContent = p.name;
    sel.appendChild(opt);
  });
}

/* ---------------------------------------------------------------------
   CONTACT FORM
   --------------------------------------------------------------------- */
function initContactForm(){
  const form = document.querySelector("[data-enquiry-form]");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    let valid = true;

    const fields = form.querySelectorAll("[required]");

    fields.forEach(f => {
      const wrap = f.closest(".form-field");

      if (!f.value.trim()){
        wrap.classList.add("error");
        valid = false;
      } else {
        wrap.classList.remove("error");
      }
    });

    const emailField = form.querySelector('[name="email"]');

    if (
      emailField &&
      emailField.value &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailField.value)
    ){
      emailField.closest(".form-field").classList.add("error");
      valid = false;
    }

    if (!valid) return;

    const data = Object.fromEntries(
      new FormData(form).entries()
    );

    const successBox = form.querySelector(".form-success");

    successBox.classList.add("show");

    successBox.innerHTML =
      `Thank you, ${data.name}. Your enquiry has been recorded. For a fast response, tap "Send via WhatsApp" below.`;

    const waMsg =
      `New Enquiry — Nimay Impex Website\n` +
      `Name: ${data.name}\n` +
      `Company: ${data.company || "-"}\n` +
      `Email: ${data.email}\n` +
      `Phone: ${data.phone || "-"}\n` +
      `Country: ${data.country || "-"}\n` +
      `Interested Product: ${data.product || "-"}\n` +
      `Quantity: ${data.quantity || "-"}\n` +
      `Message: ${data.message || "-"}`;

   window.open(waLink(waMsg), "_blank");

form.reset();
  });
}

/* ---------------------------------------------------------------------
   INIT
   --------------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", () => {
  initNavbar();
  initBackToTop();
  initLightbox();
  initProductModal();
  fillProductSelect();
  initContactForm();

  buildCategoryPreview();
  buildGallery();
  initReveal();

  if (document.querySelector("[data-product-grid]")){
    initProductFilters();
  }

  // wire every whatsapp / email / phone quick-action link found on the page
  document.querySelectorAll("[data-quote-btn]").forEach(btn => {
    btn.href = waLink("Hello Nimay Impex, I would like to request a quote.");
  });
});